<a id="readme-top"></a>

<br>

<!-- table of contents -->
<details>
  <summary>Table of Contents</summary>
  <ol>
    <li><a href="#installation">How do I install Whale Clinc?</a></li>
    <li><a href="#running">How do I run Whale Clinic?</a></li>
  </ol>
</details>

<br>

<hr>

<br>

<a id="installation"></a>

# Installation

<br>

1. Download and install <a href="https://code.visualstudio.com/download">Visual Studio Code</a>.

2. Download and install <a href="https://desktop.github.com/">Github Desktop</a>.

3. Download and install git.
  ```
  npm install -g git
  ```

4. Clone the Home:Bound repository.
  ```sh
   gh repo clone SzeXinWei/ESD-ABC-Clinic
  ```

5. Launch GitHub Desktop and select the ESD-ABC-Clinic repository. 

6. Select the <b>singpass-apptbooking</b> branch.

7. Start WAMP/MAMP on your machine.

8. Start the Whale Clinic application by keying the following command into the terminal or command prompt. 
  ```
  npm run start
  ```

9. Access <b>localhost:3001</b> in your browser.

<br>

<a id="running"></a>

# Running

<p align="right">(<a href="#readme-top">back to top</a>)</p>

The following endpoints are used to accomplish these tasks:

<table>
  <thead>
    <th>Endpoint</th>
    <th>HTTP Methods</th>
    <th>Task</th>
  </thead>
  <tbody>
    <tr>
      <td>/medicine</td>
      <td>GET, POST</td>
      <td>Returns everything in medicine inventory.</td>
    </tr>
    <tr>  
      <td>/medicine/admin</td>
      <td>GET, POST</td>
      <td>Access medicine that is running low in stock.</td>
    </tr>
    <tr>  
      <td>/medicine/update</td>
      <td>POST, PUT, GET</td>
      <td>Create a new medicine and add to medicine inventory.</td>
    </tr>
    <tr>  
      <td>/medicine/ < string:medicineName > </td>
      <td>PUT</td>
      <td>Update information about an existing medicine in the medicine inventory.</td>
    </tr>
    <tr>  
      <td>/queue</td>
      <td>GET</td>
      <td>Returns information about patients in the queue.</td>
    </tr>
    <tr>  
      <td>/queue</td>
      <td>POST</td>
      <td>Adds a new patient to the queue.</td>
    </tr>
    <tr>  
      <td>/queue</td>
      <td>DELETE</td>
      <td>Remove a patient from the queue.</td>
    </tr>
    <tr>  
      <td>/appointment</td>
      <td>GET</td>
      <td>Return information about all appointments.</td>
    </tr>
    <tr>  
      <td>/appointment/appointmentID</td>
      <td>GET</td>
      <td>Searches for a specific appointment based on the appointment ID.</td>
    </tr>
    <tr>  
      <td>/appointment/appointmentID</td>
      <td>POST, PUT</td>
      <td>Create a new appointment.</td>
    </tr>
  </tbody>
</table>

<br><br>
