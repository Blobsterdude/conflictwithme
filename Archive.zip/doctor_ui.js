// initialising elements to be passed into data --> sent to prescribe_medicine
queueNo = 0;
var medicine = {};

const prescribe_medicine_url = "http://127.0.0.1:5200/prescribe_medicine";


// add inputs
function addMedicine() {
    inputElem = document.getElementById('inputs');
    inputElem.innerHTML += `
        <div class="input-group mb-3">
            <input type="text" class="form-control" placeholder="Medicine Name" aria-label="Medicine Name" aria-describedby="button-addon2">
            <input type="text" class="form-control" placeholder="Medicine Quantity" aria-label="Medicine Quantity" aria-describedby="button-addon2">
            <button type="button" class="btn btn-danger" onclick="removeMedicine()">
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-dash-circle-fill" viewBox="0 0 16 16">
                    <path d="M16 8A8 8 0 1 1 0 8a8 8 0 0 1 16 0zM4.5 7.5a.5.5 0 0 0 0 1h7a.5.5 0 0 0 0-1h-7z"/>
                </svg>
                <i class="bi bi-dash-circle-fill"></i>
                Remove
            </button>
        </div>

        <div id="inputs"></div>
     `
}
 
// remove inputs 
function removeMedicine() {
    button = event.target
    parent = button.parentNode
    parent.remove()
}

// retrieve q no. 
    // queue = document.getElementById("queue")
    // queueNo = queue.value



// retrieve medicine name and quantity 
    parents = document.getElementsByClassName("input-group");
    medicineInput = Array.prototype.slice.call(parents, 1);

    medicineInput.forEach(med => {
    medicineName = med.childNodes[1].value;
    medicineQty = parseInt(med.childNodes[3].value);

    medicine[medicineName] = medicineQty
});


// communicating with prescribe_medicine

function sendMedicine(){
    // retrieve q no. 
    // queue = document.getElementById("queue")
    // queueNo = queue.value
    // console.log(queueNo)

     // retrieve patientId
     patient = document.getElementById("patientId")
     patientId = patient.value
     console.log(patientId)

    // retrieve medicine name and quantity 
    parents = document.getElementsByClassName("input-group");
    medicineInput = Array.prototype.slice.call(parents, 1);

    medicineInput.forEach(med => {
    medicineName = med.childNodes[1].value;
    medicineQty = parseInt(med.childNodes[3].value);

    medicine[medicineName] = medicineQty
    })
    
    const data = {'patientId': patientId,'medicineName':medicineName,'medicineQty':medicineQty}
    // console.log(data)
    let jsonData = JSON.stringify(data)
    // console.log(jsonData) 
    fetch('http://127.0.0.1:5200/prescribe_medicine',{
        method:"POST",
        headers:{
            'Content-Type':'application/json'
        },
        body:jsonData
    })
    .then(response => response.json())
    .then(data => {console.log(data);})
    // .then(response=>{
    //     console.log("hello")
    //     console.log(response.data)
    //     console.log("bye")
    // })
    .catch(error=>{
        
    })

    
    
    }
